'use client';

/**
 * FontAwesome 6 Icon Component Stories
 * Built for the Citizenly Philippine barangay management system
 */

import type { Meta, StoryObj } from '@storybook/react';
import Icon from './Icon';

const meta: Meta<typeof Icon> = {
  title: 'Atoms/Icon',
  component: Icon,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component: 'FontAwesome 6 icon component using CDN kit for the Philippine barangay management system.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    name: {
      description: 'Icon name from the barangay management system icon map',
      control: { type: 'select' },
      options: [
        'dashboard',
        'home',
        'users',
        'user',
        'building',
        'document',
        'certificate',
        'gavel',
        'map-marker',
        'chart-bar',
        'plus',
        'edit',
        'search',
        'chevron-left',
        'check',
        'settings',
        'help',
        'mail',
        'barangay',
        'resident',
        'household',
        'senior-citizen',
        'pwd',
        'ofw',
        'health',
        'education',
        'welfare',
      ],
    },
    style: {
      description: 'FontAwesome 6 icon style',
      control: { type: 'select' },
      options: ['solid', 'regular', 'light', 'thin', 'duotone', 'brands'],
    },
    size: {
      description: 'Icon size',
      control: { type: 'select' },
      options: ['xs', 'sm', 'md', 'lg', 'xl', '2xl', '3xl'],
    },
    color: {
      description: 'Icon color theme',
      control: { type: 'select' },
      options: ['primary', 'secondary', 'success', 'warning', 'danger', 'white', 'black', 'inherit', 'gov-blue', 'gov-red', 'gov-yellow'],
    },
    fixedWidth: {
      description: 'Use fixed width for consistent alignment',
      control: { type: 'boolean' },
    },
    spin: {
      description: 'Animate icon with spinning motion',
      control: { type: 'boolean' },
    },
    pulse: {
      description: 'Animate icon with pulsing motion',
      control: { type: 'boolean' },
    },
    flip: {
      description: 'Flip icon direction',
      control: { type: 'select' },
      options: [undefined, 'horizontal', 'vertical', 'both'],
    },
    rotation: {
      description: 'Rotate icon by degrees',
      control: { type: 'select' },
      options: [undefined, 90, 180, 270],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Icon>;

// Default Icon
export const Default: Story = {
  args: {
    name: 'home',
    size: 'md',
    color: 'inherit',
  },
};

// Different Sizes
export const Sizes: Story = {
  render: () => (
    <div className="flex items-center space-x-4">
      <Icon name="home" size="xs" />
      <Icon name="home" size="sm" />
      <Icon name="home" size="md" />
      <Icon name="home" size="lg" />
      <Icon name="home" size="xl" />
      <Icon name="home" size="2xl" />
      <Icon name="home" size="3xl" />
    </div>
  ),
};

// Different Colors
export const Colors: Story = {
  render: () => (
    <div className="flex items-center space-x-4">
      <Icon name="home" color="primary" />
      <Icon name="home" color="secondary" />
      <Icon name="home" color="success" />
      <Icon name="home" color="warning" />
      <Icon name="home" color="danger" />
    </div>
  ),
};

// Philippine Government Colors
export const GovernmentColors: Story = {
  render: () => (
    <div className="flex items-center space-x-4 p-4">
      <div className="flex flex-col items-center space-y-2">
        <Icon name="flag" color="gov-blue" size="2xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Gov Blue</span>
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Icon name="flag" color="gov-red" size="2xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Gov Red</span>
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Icon name="flag" color="gov-yellow" size="2xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Gov Yellow</span>
      </div>
    </div>
  ),
};

// Different Styles
export const Styles: Story = {
  render: () => (
    <div className="flex items-center space-x-4">
      <div className="flex flex-col items-center space-y-2">
        <Icon name="home" style="solid" size="xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Solid</span>
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Icon name="home" style="regular" size="xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Regular</span>
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Icon name="home" style="light" size="xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Light</span>
      </div>
      <div className="flex flex-col items-center space-y-2">
        <Icon name="home" style="duotone" size="xl" />
        <span className="text-sm text-gray-600 dark:text-gray-400">Duotone</span>
      </div>
    </div>
  ),
};

// Navigation Icons
export const NavigationIcons: Story = {
  render: () => (
    <div className="grid grid-cols-6 gap-6 p-4">
      {[
        { name: 'dashboard', label: 'Dashboard' },
        { name: 'home', label: 'Home' },
        { name: 'users', label: 'Residents' },
        { name: 'building', label: 'Barangay' },
        { name: 'chart-bar', label: 'Reports' },
        { name: 'settings', label: 'Settings' },
      ].map(({ name, label }) => (
        <div key={name} className="flex flex-col items-center space-y-2 p-2">
          <Icon name={name} size="2xl" color="primary" />
          <span className="text-sm text-center text-gray-600 dark:text-gray-400">{label}</span>
        </div>
      ))}
    </div>
  ),
};

// Barangay Management Icons
export const BarangayIcons: Story = {
  render: () => (
    <div className="grid grid-cols-6 gap-6 p-4">
      {[
        { name: 'barangay', label: 'Barangay' },
        { name: 'resident', label: 'Resident' },
        { name: 'household', label: 'Household' },
        { name: 'senior-citizen', label: 'Senior Citizen' },
        { name: 'pwd', label: 'PWD' },
        { name: 'ofw', label: 'OFW' },
        { name: 'health', label: 'Health' },
        { name: 'education', label: 'Education' },
        { name: 'welfare', label: 'Social Welfare' },
        { name: 'certificate', label: 'Certificate' },
        { name: 'gavel', label: 'Legal' },
        { name: 'disaster', label: 'Disaster Risk' },
      ].map(({ name, label }) => (
        <div key={name} className="flex flex-col items-center space-y-2 p-2">
          <Icon name={name} size="2xl" color="primary" />
          <span className="text-sm text-center text-gray-600 dark:text-gray-400">{label}</span>
        </div>
      ))}
    </div>
  ),
};

// Interactive Icons
export const Interactive: Story = {
  render: () => (
    <div className="flex items-center space-x-4">
      <Icon name="search" size="lg" spin />
      <Icon name="bell" size="lg" pulse />
      <Icon name="chevron-left" size="lg" />
      <Icon name="chevron-right" size="lg" flip="horizontal" />
      <Icon name="settings" size="lg" rotation={90} />
    </div>
  ),
};

// Fixed Width for Lists
export const FixedWidth: Story = {
  render: () => (
    <div className="space-y-2">
      <div className="flex items-center space-x-2">
        <Icon name="home" fixedWidth />
        <span>Home</span>
      </div>
      <div className="flex items-center space-x-2">
        <Icon name="users" fixedWidth />
        <span>Residents</span>
      </div>
      <div className="flex items-center space-x-2">
        <Icon name="building" fixedWidth />
        <span>Barangay</span>
      </div>
      <div className="flex items-center space-x-2">
        <Icon name="chart-bar" fixedWidth />
        <span>Reports</span>
      </div>
    </div>
  ),
};

// Dark Mode Support
export const DarkMode: Story = {
  render: () => (
    <div className="p-6 space-y-6 bg-gray-100 dark:bg-gray-900">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Light Mode</h3>
      <div className="flex items-center space-x-4">
        <Icon name="home" size="xl" color="primary" />
        <Icon name="users" size="xl" color="secondary" />
        <Icon name="chart-bar" size="xl" color="success" />
        <Icon name="settings" size="xl" color="warning" />
      </div>
      
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Dark Mode (same colors)</h3>
      <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg">
        <Icon name="home" size="xl" color="primary" />
        <Icon name="users" size="xl" color="secondary" />
        <Icon name="chart-bar" size="xl" color="success" />
        <Icon name="settings" size="xl" color="warning" />
      </div>
    </div>
  ),
};

// All Available Icons Grid
export const AllIcons: Story = {
  render: () => (
    <div className="grid grid-cols-8 gap-4 p-4 max-h-96 overflow-y-auto">
      {Object.keys({
        'dashboard': 'Dashboard',
        'home': 'Home',
        'users': 'Users',
        'user': 'User',
        'building': 'Building',
        'store': 'Store',
        'menu': 'Menu',
        'document': 'Document',
        'certificate': 'Certificate',
        'clipboard': 'Clipboard',
        'gavel': 'Legal',
        'shield': 'Shield',
        'flag': 'Flag',
        'map': 'Map',
        'location': 'Location',
        'globe': 'Globe',
        'chart-bar': 'Chart',
        'analytics': 'Analytics',
        'plus': 'Add',
        'edit': 'Edit',
        'delete': 'Delete',
        'search': 'Search',
        'check': 'Check',
        'bell': 'Notifications',
        'settings': 'Settings',
        'help': 'Help',
        'mail': 'Mail',
        'phone': 'Phone',
        'barangay': 'Barangay',
        'resident': 'Resident',
        'household': 'Household',
        'senior-citizen': 'Senior',
        'pwd': 'PWD',
        'ofw': 'OFW',
        'health': 'Health',
        'education': 'Education',
        'welfare': 'Welfare',
      }).map((iconName) => (
        <div key={iconName} className="flex flex-col items-center space-y-1 p-2">
          <Icon name={iconName} size="xl" color="primary" />
          <span className="text-xs text-center text-gray-600 dark:text-gray-400 leading-tight">
            {iconName.replace('-', ' ')}
          </span>
        </div>
      ))}
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All available icons in the barangay management system icon map.',
      },
    },
  },
};