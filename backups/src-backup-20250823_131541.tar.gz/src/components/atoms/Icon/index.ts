/**
 * Icon Component Export
 * 
 * FontAwesome 6 icon component using CDN kit.
 * Built for Philippine barangay management systems with accessibility and theming.
 */

export { default, type IconProps, iconVariants, iconMap } from './Icon';