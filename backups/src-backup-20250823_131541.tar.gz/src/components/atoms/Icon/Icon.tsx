'use client';

/**
 * FontAwesome 6 Icon Component
 * Built for the Citizenly Philippine barangay management system
 * Uses FontAwesome 6 CDN kit for Pro icons
 */

import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { clsx } from 'clsx';

// Icon variant styles using pure Tailwind classes
const iconVariants = cva('inline-block', {
  variants: {
    size: {
      xs: 'w-3 h-3 text-xs',
      sm: 'w-4 h-4 text-sm',
      md: 'w-5 h-5 text-base',
      lg: 'w-6 h-6 text-lg',
      xl: 'w-7 h-7 text-xl',
      '2xl': 'w-8 h-8 text-2xl',
      '3xl': 'w-10 h-10 text-3xl',
    },
    color: {
      primary: 'text-blue-600 dark:text-blue-400',
      secondary: 'text-gray-600 dark:text-gray-400',
      success: 'text-green-600 dark:text-green-400',
      warning: 'text-yellow-600 dark:text-yellow-400',
      danger: 'text-red-600 dark:text-red-400',
      white: 'text-white',
      black: 'text-black dark:text-white',
      inherit: 'text-inherit',
      
      // Philippine government colors
      'gov-blue': 'text-blue-800 dark:text-blue-300',
      'gov-red': 'text-red-700 dark:text-red-400',
      'gov-yellow': 'text-yellow-500 dark:text-yellow-300',
    },
  },
  defaultVariants: {
    size: 'md',
    color: 'inherit',
  },
});

// FontAwesome 6 icon mapping for barangay management system
const iconMap: Record<string, string> = {
  // Navigation & Dashboard
  'dashboard': 'fas fa-tachometer-alt',
  'tachometer-alt': 'fas fa-tachometer-alt',
  'home': 'fas fa-home',
  'users': 'fas fa-users',
  'user': 'fas fa-user',
  'user-plus': 'fas fa-user-plus',
  'user-edit': 'fas fa-user-edit',
  'building': 'fas fa-building',
  'store': 'fas fa-store',
  'menu': 'fas fa-bars',
  'bars': 'fas fa-bars',
  'close': 'fas fa-times',
  'times': 'fas fa-times',

  // Documents & Certification
  'document': 'fas fa-file-alt',
  'file-alt': 'fas fa-file-alt',
  'certificate': 'fas fa-certificate',
  'file-text': 'fas fa-file-text',
  'clipboard': 'fas fa-clipboard',
  'clipboard-list': 'fas fa-clipboard-list',
  'file-check': 'fas fa-file-check',
  'file-signature': 'fas fa-file-signature',
  'id-card': 'fas fa-id-card',

  // Government & Legal
  'judiciary': 'fas fa-gavel',
  'gavel': 'fas fa-gavel',
  'balance-scale': 'fas fa-balance-scale',
  'scales': 'fas fa-balance-scale',
  'shield-alt': 'fas fa-shield-alt',
  'shield': 'fas fa-shield-alt',
  'flag': 'fas fa-flag',
  'handshake': 'fas fa-handshake',

  // Geographic & Location
  'map': 'fas fa-map',
  'map-marker-alt': 'fas fa-map-marker-alt',
  'map-marker': 'fas fa-map-marker-alt',
  'location': 'fas fa-map-marker-alt',
  'globe': 'fas fa-globe',

  // Reports & Analytics
  'reports': 'fas fa-chart-bar',
  'chart-bar': 'fas fa-chart-bar',
  'bar-chart': 'fas fa-chart-bar',
  'chart-line': 'fas fa-chart-line',
  'analytics': 'fas fa-chart-line',
  'chart-pie': 'fas fa-chart-pie',
  'statistics': 'fas fa-chart-pie',

  // Actions & Controls
  'plus': 'fas fa-plus',
  'plus-circle': 'fas fa-plus-circle',
  'edit': 'fas fa-edit',
  'delete': 'fas fa-trash',
  'trash': 'fas fa-trash',
  'search': 'fas fa-search',
  'filter': 'fas fa-filter',
  'sort': 'fas fa-sort',
  'sort-up': 'fas fa-sort-up',
  'sort-down': 'fas fa-sort-down',

  // Interface Elements
  'chevron-left': 'fas fa-chevron-left',
  'chevron-right': 'fas fa-chevron-right',
  'chevron-up': 'fas fa-chevron-up',
  'chevron-down': 'fas fa-chevron-down',
  'arrow-left': 'fas fa-arrow-left',
  'arrow-right': 'fas fa-arrow-right',

  // Status & Notifications
  'check': 'fas fa-check',
  'check-circle': 'fas fa-check-circle',
  'exclamation-triangle': 'fas fa-exclamation-triangle',
  'exclamation-circle': 'fas fa-exclamation-circle',
  'info-circle': 'fas fa-info-circle',
  'bell': 'fas fa-bell',

  // Settings & Configuration
  'settings': 'fas fa-cog',
  'cog': 'fas fa-cog',
  'tools': 'fas fa-tools',
  'wrench': 'fas fa-wrench',

  // Help & Support
  'help': 'fas fa-question-circle',
  'question-circle': 'fas fa-question-circle',
  'info': 'fas fa-info',

  // Communication
  'mail': 'fas fa-envelope',
  'envelope': 'fas fa-envelope',
  'phone': 'fas fa-phone',
  'message': 'fas fa-comment',
  'comment': 'fas fa-comment',

  // Barangay Specific
  'barangay': 'fas fa-home',
  'resident': 'fas fa-user',
  'household': 'fas fa-users',
  'households': 'fas fa-home',
  'family': 'fas fa-users',
  'senior-citizen': 'fas fa-user-clock',
  'pwd': 'fas fa-wheelchair',
  'wheelchair': 'fas fa-wheelchair',
  'ofw': 'fas fa-plane-departure',
  'plane-departure': 'fas fa-plane-departure',
  'plane': 'fas fa-plane',
  'voter': 'fas fa-vote-yea',
  'vote-yea': 'fas fa-vote-yea',
  'captain': 'fas fa-user-tie',
  'user-tie': 'fas fa-user-tie',
  'treasurer': 'fas fa-coins',
  'coins': 'fas fa-coins',
  'health': 'fas fa-heartbeat',
  'heartbeat': 'fas fa-heartbeat',
  'education': 'fas fa-graduation-cap',
  'graduation-cap': 'fas fa-graduation-cap',
  'welfare': 'fas fa-hands-helping',
  'hands-helping': 'fas fa-hands-helping',
  'disaster': 'fas fa-life-ring',
  'life-ring': 'fas fa-life-ring',

  // Business & Commerce
  'business': 'fas fa-building',
};

// Icon component props
export interface IconProps extends VariantProps<typeof iconVariants> {
  // Icon identification
  name: string;
  
  // FontAwesome 6 specific props
  style?: 'solid' | 'regular' | 'light' | 'thin' | 'duotone' | 'brands'; // FontAwesome 6 styles
  fixedWidth?: boolean;
  spin?: boolean;
  pulse?: boolean;
  flip?: 'horizontal' | 'vertical' | 'both';
  rotation?: 90 | 180 | 270;
  
  // Standard props
  className?: string;
  title?: string;
  'aria-label'?: string;
  'aria-hidden'?: boolean;
  onClick?: () => void;
}

// Main Icon component
export default function Icon({
  name,
  style = 'solid',
  size,
  color,
  fixedWidth = false,
  spin = false,
  pulse = false,
  flip,
  rotation,
  className,
  title,
  'aria-label': ariaLabel,
  'aria-hidden': ariaHidden,
  onClick,
}: IconProps) {
  const iconClasses = clsx(iconVariants({ size, color }), className);

  // Get the FontAwesome class based on name and style
  let faClass = iconMap[name.toLowerCase()];
  
  if (!faClass) {
    console.warn(`Icon "${name}" not found in FontAwesome icon map`);
    // Return a fallback icon
    return (
      <div
        className={clsx(iconClasses, 'flex items-center justify-center bg-gray-200 dark:bg-gray-700 text-gray-500 dark:text-gray-400 rounded border font-mono')}
        title={title || `Missing icon: ${name}`}
        aria-label={ariaLabel || `Missing icon: ${name}`}
        aria-hidden={ariaHidden}
        onClick={onClick}
      >
        ?
      </div>
    );
  }

  // Replace default style prefix with requested style
  const stylePrefix = {
    solid: 'fas',
    regular: 'far',
    light: 'fal',
    thin: 'fat',
    duotone: 'fad',
    brands: 'fab',
  }[style];

  faClass = faClass.replace(/^fa[slrtdb]/, stylePrefix);

  // Build additional FontAwesome and semantic classes
  const additionalClasses = [];
  
  // FontAwesome classes
  if (fixedWidth) additionalClasses.push('fa-fw');
  if (spin) additionalClasses.push('fa-spin');
  if (pulse) additionalClasses.push('fa-pulse');
  if (flip) {
    if (flip === 'horizontal') additionalClasses.push('fa-flip-horizontal');
    else if (flip === 'vertical') additionalClasses.push('fa-flip-vertical');
    else if (flip === 'both') additionalClasses.push('fa-flip-horizontal', 'fa-flip-vertical');
  }
  if (rotation) additionalClasses.push(`fa-rotate-${rotation}`);
  
  // Semantic modifier classes using Tailwind
  if (fixedWidth) additionalClasses.push('w-auto');
  if (spin) additionalClasses.push('animate-spin');
  if (pulse) additionalClasses.push('animate-pulse');
  if (flip) {
    if (flip === 'horizontal') additionalClasses.push('scale-x-[-1]');
    else if (flip === 'vertical') additionalClasses.push('scale-y-[-1]');
    else if (flip === 'both') additionalClasses.push('scale-x-[-1] scale-y-[-1]');
  }
  if (rotation) {
    const rotationClasses = {
      90: 'rotate-90',
      180: 'rotate-180',
      270: 'rotate-[270deg]'
    };
    additionalClasses.push(rotationClasses[rotation] || '');
  }

  const finalClasses = clsx(faClass, ...additionalClasses, iconClasses);

  return (
    <i
      className={finalClasses}
      title={title}
      aria-label={ariaLabel}
      aria-hidden={ariaHidden}
      onClick={onClick}
    />
  );
}

// Export utilities
export { iconVariants, iconMap };