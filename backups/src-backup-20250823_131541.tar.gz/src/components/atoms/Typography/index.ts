export { Typography, Heading1, Heading2, Heading3, BodyText, Caption } from './Typography';
export type { TypographyProps } from './Typography';
