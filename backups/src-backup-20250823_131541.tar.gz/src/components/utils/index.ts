// Utility Components - HOCs and helper components
// Note: ProtectedRoute has been moved to organisms as it's a complex component
