export { default as ProtectedRoute } from './ProtectedRoute';
