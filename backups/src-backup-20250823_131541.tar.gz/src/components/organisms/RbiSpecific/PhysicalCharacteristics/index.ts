export { default } from './PhysicalCharacteristics';
