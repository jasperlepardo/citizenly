export { default } from './ResidentStatusSelector';
