export * from './Resident/PersonalInformation';
export * from './Resident/ContactInformation';
export * from './Resident/PhysicalPersonalDetails';
export * from './Resident/SectoralInformation';
export * from './Resident/MigrationInformation';