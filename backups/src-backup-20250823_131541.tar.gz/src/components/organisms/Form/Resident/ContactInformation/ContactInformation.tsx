import React from 'react';
import { ContactDetails, ContactDetailsData } from './FormField/ContactDetails';
import { HouseholdInformation, HouseholdInformationData } from './FormField/HouseholdInformation';

export interface ContactInformationFormProps {
  formData: {
    email?: string;
    phoneNumber?: string;
    mobileNumber?: string;
    householdCode?: string;
  };
  onChange: (field: string, value: string | number | boolean | null) => void;
  errors: Record<string, string>;
}

export function ContactInformationForm({ 
  formData, 
  onChange, 
  errors
}: ContactInformationFormProps) {

  // Map form data to ContactDetails component props
  const contactDetailsValue: ContactDetailsData = {
    email: formData.email || '',
    phoneNumber: formData.phoneNumber || '',
    mobileNumber: formData.mobileNumber || '',
  };

  // Map form data to HouseholdInformation component props
  const householdInfoValue: HouseholdInformationData = {
    householdCode: formData.householdCode || '',
  };

  // Handle changes from ContactDetails component
  const handleContactDetailsChange = (value: ContactDetailsData) => {
    Object.entries(value).forEach(([field, fieldValue]) => {
      onChange(field as keyof typeof value, fieldValue);
    });
  };

  // Handle changes from HouseholdInformation component
  const handleHouseholdInfoChange = (value: HouseholdInformationData) => {
    Object.entries(value).forEach(([field, fieldValue]) => {
      onChange(field as keyof typeof value, fieldValue);
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-300 dark:border-gray-600 shadow-xs p-6">
      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-200">Contact Information</h2>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            Contact details and household assignment information.
          </p>
        </div>

        <div className="space-y-8">
          {/* Contact Details */}
          <ContactDetails
            value={contactDetailsValue}
            onChange={handleContactDetailsChange}
            errors={errors}
          />

          {/* Household Information */}
          <HouseholdInformation
            value={householdInfoValue}
            onChange={handleHouseholdInfoChange}
            errors={errors}
          />
        </div>
      </div>
    </div>
  );
}

export default ContactInformationForm;