'use client';

import React from 'react';
import Image from 'next/image';

const imgDots = 'http://localhost:3845/assets/ab2f4963fe08a77bf05c65af4e1be5c6eb4c8d1d.svg';
const imgList = 'http://localhost:3845/assets/446e2a5e5c3189109c4e06042fc9f4d68e425e77.svg';
const imgSort = 'http://localhost:3845/assets/bc3fc4b84bc72114e8c931780b6eba6740c31a61.svg';
const imgFilter = 'http://localhost:3845/assets/4f84effa9e72e78bbd4e3956cc3993a53bb161bb.svg';
const imgMore = 'http://localhost:3845/assets/9473b7d86c016dbb025d43bcf84d2d7a6e93f3f3.svg';

interface TableProps {
  children: React.ReactNode;
  className?: string;
}

export function Table({ children, className = '' }: TableProps) {
  return <div className={`flex flex-col ${className}`}>{children}</div>;
}

interface TableBodyProps {
  children: React.ReactNode;
}

export function TableBody({ children }: TableBodyProps) {
  return <div className="flex flex-col">{children}</div>;
}

interface TableRowProps {
  children: React.ReactNode;
  className?: string;
}

export function TableRow({ children, className = '' }: TableRowProps) {
  return (
    <div
      className={`bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 flex items-center transition-colors ${className}`}
    >
      {children}
    </div>
  );
}

interface TableCellProps {
  children?: React.ReactNode;
  className?: string;
  type?: 'content' | 'checkbox' | 'action';
  checkbox?: {
    checked?: boolean;
    onChange?: (checked: boolean) => void;
  };
}

export function TableCell({
  children,
  className = '',
  type = 'content',
  checkbox,
}: TableCellProps) {
  if (type === 'checkbox') {
    return (
      <div className={`p-2 ${className}`}>
        <button
          onClick={() => checkbox?.onChange?.(!checkbox.checked)}
          className="flex items-center justify-center rounded-sm border border-gray-300 dark:border-gray-600 p-0"
        >
          <div className="flex size-4 items-center justify-center">
            {checkbox?.checked && (
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <path
                  d="M10 3L4.5 8.5L2 6"
                  stroke="#1d4ed8"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            )}
          </div>
        </button>
      </div>
    );
  }

  if (type === 'action') {
    return (
      <div className={`p-1 ${className}`}>
        <button className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 rounded-sm border border-gray-300 dark:border-gray-600 p-2 transition-colors">
          <div className="size-5">
            <Image alt="actions" className="block size-full" src={imgDots} width={20} height={20} />
          </div>
        </button>
      </div>
    );
  }

  return (
    <div className={`flex-1 p-2 ${className}`}>
      <div className="font-body text-base font-normal leading-5 text-gray-600 dark:text-gray-400">{children}</div>
    </div>
  );
}

interface TableControlsProps {
  selectAll?: {
    checked: boolean;
    onChange: (checked: boolean) => void;
    label?: string;
  };
  actions?: React.ReactNode;
  search?: {
    value: string;
    onChange: (value: string) => void;
    placeholder?: string;
  };
}

export function TableControls({ selectAll, actions, search }: TableControlsProps) {
  return (
    <div className="bg-white dark:bg-gray-800 flex items-center justify-between p-0">
      <div className="flex items-center">
        {selectAll && (
          <div className="flex items-center gap-2 p-2">
            <button
              onClick={() => selectAll.onChange(!selectAll.checked)}
              className="flex items-center gap-2"
            >
              <div className="flex items-center justify-center rounded-sm border border-gray-300 dark:border-gray-600 p-0">
                <div className="flex size-4 items-center justify-center">
                  {selectAll.checked && (
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path
                        d="M10 3L4.5 8.5L2 6"
                        stroke="#1d4ed8"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  )}
                </div>
              </div>
              <span className="font-body text-base font-normal text-gray-600 dark:text-gray-400">
                {selectAll.label || 'Select all'}
              </span>
            </button>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center gap-0 p-1">
          <button className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 flex items-center gap-1 rounded-sm border border-gray-300 dark:border-gray-600 p-2 transition-colors">
            <div className="size-5">
              <Image alt="list" className="block size-full" src={imgList} width={20} height={20} />
            </div>
            <span className="px-1 font-body text-base font-medium text-gray-600 dark:text-gray-400">Properties</span>
          </button>

          <button className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 ml-1 flex items-center gap-1 rounded-sm border border-gray-300 dark:border-gray-600 p-2 transition-colors">
            <div className="size-5">
              <Image alt="sort" className="block size-full" src={imgSort} width={20} height={20} />
            </div>
            <span className="px-1 font-body text-base font-medium text-gray-600 dark:text-gray-400">Sort</span>
          </button>

          <button className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 ml-1 flex items-center gap-1 rounded-sm border border-gray-300 dark:border-gray-600 p-2 transition-colors">
            <div className="size-5">
              <Image
                alt="filter"
                className="block size-full"
                src={imgFilter}
                width={20}
                height={20}
              />
            </div>
            <span className="px-1 font-body text-base font-medium text-gray-600 dark:text-gray-400">Filter</span>
          </button>

          <button className="bg-white dark:bg-gray-800 hover:bg-gray-50 dark:bg-gray-700 ml-1 rounded-sm border border-gray-300 dark:border-gray-600 p-1 transition-colors">
            <div className="size-5">
              <Image alt="more" className="block size-full" src={imgMore} width={20} height={20} />
            </div>
          </button>
        </div>

        {actions}
      </div>

      {search && (
        <div className="p-1">
          <div className="w-60">
            <div className="bg-white dark:bg-gray-800 relative rounded-sm">
              <div className="flex items-center gap-1 p-2">
                <div className="shrink-0">
                  <div className="flex size-5 items-center justify-center">
                    <svg className="size-3" viewBox="0 0 12 12" fill="none">
                      <path
                        d="M5.5 10C7.98528 10 10 7.98528 10 5.5C10 3.01472 7.98528 1 5.5 1C3.01472 1 1 3.01472 1 5.5C1 7.98528 3.01472 10 5.5 10Z"
                        stroke="rgba(0, 0, 0, 0.32)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                      <path
                        d="M10.7498 10.75L8.7998 8.8"
                        stroke="rgba(0, 0, 0, 0.32)"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                </div>

                <div className="flex-1 px-1">
                  <input
                    className="placeholder:text-gray-500 dark:text-gray-400 w-full border-none bg-transparent font-body text-base font-normal leading-5 text-gray-600 outline-hidden"
                    placeholder={search.placeholder || 'Search contact'}
                    value={search.value}
                    onChange={e => search.onChange(e.target.value)}
                  />
                </div>
              </div>
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 rounded-sm border border-solid border-gray-300 dark:border-gray-600"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
