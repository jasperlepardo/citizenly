export { Badge, type BadgeProps } from './Badge';
export { default } from './Badge';