export { ResidentForm } from './ResidentForm';
export { default } from './ResidentForm';