// Colors component removed - now using pure Storybook documentation
// See Colors.stories.tsx for comprehensive color system documentation
