export { default as SectoralInfo } from './SectoralInfo';
