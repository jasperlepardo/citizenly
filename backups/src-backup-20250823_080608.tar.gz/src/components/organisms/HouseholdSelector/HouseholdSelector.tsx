'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { CreateHouseholdModal } from '../CreateHouseholdModal';
import { logger, logError } from '@/lib/logging/secure-logger';

interface Region {
  code: string;
  name: string;
}

interface Province {
  code: string;
  name: string;
  psgc_regions: Region;
}

interface CityMunicipality {
  code: string;
  name: string;
  type: string;
  psgc_provinces: Province;
}

interface Household {
  code: string;
  house_number?: string;
  street_id: string;
  subdivision_id?: string;
  barangay_code: string;
  head_resident?: {
    id: string;
    first_name: string;
    middle_name?: string;
    last_name: string;
  };
  member_count?: number;
  // Related data from JOINs
  geo_streets: {
    id: string;
    name: string;
  };
  geo_subdivisions?: {
    id: string;
    name: string;
    type: string;
  };
  // Geographic information for display
  region_info?: {
    code: string;
    name: string;
  };
  province_info?: {
    code: string;
    name: string;
  };
  city_municipality_info?: {
    code: string;
    name: string;
    type: string;
  };
  barangay_info?: {
    code: string;
    name: string;
  };
}

interface HouseholdSelectorProps {
  value: string;
  onSelect: (householdCode: string | null) => void;
  error?: string;
  placeholder?: string;
}

export default function HouseholdSelector({
  value,
  onSelect,
  error,
  placeholder = '🏠 Search households or leave blank to create new',
}: HouseholdSelectorProps) {
  const { userProfile } = useAuth();
  const [households, setHouseholds] = useState<Household[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  // Load households for the user's barangay
  const loadHouseholds = useCallback(async () => {
    if (!userProfile?.barangay_code) {
      logger.debug('No barangay_code available, cannot load households', { userProfile });
      return;
    }

    logger.debug('Loading households for barangay', {
      barangayCode: userProfile.barangay_code,
      userProfileId: userProfile.id,
    });
    setLoading(true);
    try {
      // Get households with optional head resident, street, and subdivision info
      const { data: householdsData, error } = await supabase
        .from('households')
        .select(
          `
            code,
            name,
            house_number,
            street_id,
            subdivision_id,
            barangay_code,
            household_head_id,
            geo_streets(
              id,
              name
            ),
            geo_subdivisions(
              id,
              name,
              type
            )
          `
        )
        .eq('barangay_code', userProfile.barangay_code)
        .order('code', { ascending: true });

      if (error) {
        logger.error('Error loading households', { error });
        return;
      }

      logger.debug('Raw households data from query', {
        count: householdsData?.length || 0,
        userBarangay: userProfile.barangay_code,
        rawData: householdsData,
        queryWithoutBarangayFilter: true,
      });

      console.log('🏠 HOUSEHOLD DEBUG:', {
        userBarangayCode: userProfile.barangay_code,
        householdsFound: householdsData?.length || 0,
        households: householdsData,
      });

      // Get member counts, head resident info, and geographic information for each household
      const householdsWithCounts = await Promise.all(
        (householdsData || []).map(async household => {
          // Get member count
          const { count } = await supabase
            .from('residents')
            .select('*', { count: 'exact', head: true })
            .eq('household_code', household.code);

          // Get head resident info if household_head_id exists
          let headResident = null;
          if (household.household_head_id) {
            const { data: headData } = await supabase
              .from('residents')
              .select('id, first_name, middle_name, last_name')
              .eq('id', household.household_head_id)
              .single();
            headResident = headData;
          }

          // Get geographic information from PSGC tables
          let geoInfo = {};
          try {
            // Use API endpoint to get barangay info (avoids complex nested query issues)
            const response = await fetch(`/api/psgc/lookup?code=${encodeURIComponent(household.barangay_code)}`);
            let barangayData = null;
            
            if (response.ok) {
              const result = await response.json();
              barangayData = result.data;
            }

            if (barangayData) {
              // API returns flattened structure
              geoInfo = {
                barangay_info: {
                  code: barangayData.code || barangayData.barangay_code,
                  name: barangayData.name || barangayData.barangay_name,
                },
                city_municipality_info: {
                  code: barangayData.city_code,
                  name: barangayData.city_name,
                  type: barangayData.city_type,
                },
                province_info: {
                  code: barangayData.province_code,
                  name: barangayData.province_name,
                },
                region_info: {
                  code: barangayData.region_code,
                  name: barangayData.region_name,
                },
              };
            }
          } catch (geoError) {
            logger.warn('Could not load geographic info for household', {
              householdCode: household.code,
              error: geoError,
            });
          }

          return {
            ...household,
            head_resident: headResident || undefined,
            member_count: count || 0,
            // Fix geo_streets to be single object, not array
            geo_streets:
              household.geo_streets && household.geo_streets.length > 0
                ? household.geo_streets[0]
                : { id: '', name: '' },
            // Fix geo_subdivisions to be single object, not array
            geo_subdivisions:
              household.geo_subdivisions && household.geo_subdivisions.length > 0
                ? household.geo_subdivisions[0]
                : undefined,
            ...geoInfo,
          } as Household;
        })
      );

      logger.debug('Loaded households', { count: householdsWithCounts.length });
      setHouseholds(householdsWithCounts);
    } catch (error) {
      logError(error as Error, 'HOUSEHOLD_LOAD_ERROR');
    } finally {
      setLoading(false);
    }
  }, [userProfile?.barangay_code]);

  // Load households when barangay changes
  useEffect(() => {
    loadHouseholds();
  }, [loadHouseholds]);

  // Helper function to format full name
  const formatFullName = (person?: {
    first_name: string;
    middle_name?: string;
    last_name: string;
  }) => {
    if (!person) return 'No head assigned';
    return [person.first_name, person.middle_name, person.last_name].filter(Boolean).join(' ');
  };

  // Helper function to format address
  const formatAddress = (household: Household) => {
    const parts = [
      household.house_number,
      household.geo_streets?.name,
      household.geo_subdivisions?.name,
    ].filter(Boolean);
    return parts.length > 0 ? parts.join(', ') : 'No address';
  };

  // Helper function to format full address with geographic hierarchy
  const formatFullAddress = (household: Household) => {
    const localAddress = formatAddress(household);
    const geoParts = [];

    if (household.barangay_info?.name) {
      geoParts.push(`Brgy. ${household.barangay_info.name}`);
    }

    if (household.city_municipality_info?.name && household.city_municipality_info?.type) {
      geoParts.push(
        `${household.city_municipality_info.name} (${household.city_municipality_info.type})`
      );
    }

    if (household.province_info?.name) {
      geoParts.push(household.province_info.name);
    }

    if (localAddress === 'No address' && geoParts.length === 0) {
      return 'Address not available';
    }

    if (localAddress === 'No address') {
      return geoParts.join(', ');
    }

    return geoParts.length > 0 ? `${localAddress}, ${geoParts.join(', ')}` : localAddress;
  };

  // Filter households based on search term
  const filteredHouseholds = households.filter(household => {
    const searchLower = searchTerm.toLowerCase();
    return (
      household.code.toLowerCase().includes(searchLower) ||
      formatFullName(household.head_resident).toLowerCase().includes(searchLower) ||
      household.geo_streets?.name?.toLowerCase().includes(searchLower) ||
      household.house_number?.toLowerCase().includes(searchLower) ||
      household.geo_subdivisions?.name?.toLowerCase().includes(searchLower)
    );
  });

  const selectedHousehold = households.find(h => h.code === value);

  // Debug logging for selection state
  React.useEffect(() => {
    logger.debug('HouseholdSelector state', {
      value,
      householdsCount: households.length,
      selectedHousehold: selectedHousehold
        ? `${selectedHousehold.code} - ${formatFullName(selectedHousehold.head_resident)}`
        : 'None found',
    });
  }, [value, households, selectedHousehold]);

  return (
    <div className="relative">
      <div
        className={`font-montserrat relative rounded border text-base focus-within:border-transparent focus-within:ring-2 ${
          error
            ? 'border-red-500 focus-within:ring-red-500'
            : 'border-gray-300 focus-within:ring-blue-500'
        }`}
      >
        <input
          type="text"
          value={
            selectedHousehold
              ? `#${selectedHousehold.code} - ${formatFullAddress(selectedHousehold)} (${formatFullName(selectedHousehold.head_resident)})`
              : searchTerm
          }
          onChange={e => {
            setSearchTerm(e.target.value);
            setIsOpen(true);
            if (!e.target.value) {
              onSelect(null);
            }
          }}
          onFocus={() => setIsOpen(true)}
          className="w-full bg-transparent px-3 py-2 outline-hidden"
          placeholder={placeholder}
        />

        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:text-gray-300"
        >
          <svg className="size-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d={isOpen ? 'M5 15l7-7 7 7' : 'M19 9l-7 7-7-7'}
            />
          </svg>
        </button>
      </div>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute z-10 mt-1 max-h-60 w-full overflow-y-auto rounded-lg border border-gray-300 bg-white shadow-lg">
          {loading ? (
            <div className="p-3 text-center text-gray-500 dark:text-gray-500">
              <div className="animate-pulse">Loading households...</div>
            </div>
          ) : (
            <div>
              {/* Always show option to create new household */}
              <button
                type="button"
                onClick={() => {
                  setIsOpen(false);
                  setShowCreateModal(true);
                }}
                className="w-full border-b border-gray-100 p-3 text-left hover:bg-blue-50"
              >
                <div className="font-medium text-gray-600 dark:text-gray-400">+ Create New Household</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  This resident will start a new household
                </div>
              </button>

              {/* Show message when no existing households */}
              {filteredHouseholds.length === 0 && !searchTerm && (
                <div className="p-3 text-center text-gray-500 dark:text-gray-500">
                  <div className="text-sm">No existing households in this barangay</div>
                  <div className="mt-1 text-xs text-green-600">
                    ✓ Perfect! This will be the first household
                  </div>
                </div>
              )}

              {/* Show "no search results" when searching */}
              {filteredHouseholds.length === 0 && searchTerm && (
                <div className="p-3 text-center text-gray-500 dark:text-gray-500">
                  <div className="text-sm">No households match your search</div>
                </div>
              )}

              {/* Existing households */}
              {filteredHouseholds.map(household => (
                <button
                  key={household.code}
                  type="button"
                  onClick={() => {
                    onSelect(household.code);
                    setSearchTerm('');
                    setIsOpen(false);
                  }}
                  className="w-full border-b border-gray-100 p-3 text-left last:border-b-0 hover:bg-gray-50"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900 dark:text-gray-100">
                        Household #{household.code}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        Head: {formatFullName(household.head_resident)}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-500">{formatFullAddress(household)}</div>
                    </div>
                    <div className="ml-2 text-xs text-gray-500 dark:text-gray-500">
                      {household.member_count} member{household.member_count !== 1 ? 's' : ''}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Click outside to close */}
      {isOpen && <div className="fixed inset-0 z-0" onClick={() => setIsOpen(false)} />}

      {/* Error message */}
      {error && (
        <p className="mt-2 text-sm text-red-600" role="alert">
          {error}
        </p>
      )}

      {/* Create Household Modal */}
      <CreateHouseholdModal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onHouseholdCreated={householdCode => {
          logger.info('Auto-selecting newly created household', { householdCode });
          onSelect(householdCode);
          setShowCreateModal(false);
          // Refresh households list after a small delay to ensure database consistency
          setTimeout(() => {
            logger.debug('Refreshing households list');
            loadHouseholds();
          }, 500);
        }}
      />
    </div>
  );
}
