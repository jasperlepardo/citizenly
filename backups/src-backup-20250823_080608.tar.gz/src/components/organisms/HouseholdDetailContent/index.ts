export { default as HouseholdDetailContent } from './HouseholdDetailContent';
