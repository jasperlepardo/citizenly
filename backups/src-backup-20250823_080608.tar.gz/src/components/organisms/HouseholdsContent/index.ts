export { default as HouseholdsContent } from './HouseholdsContent';
