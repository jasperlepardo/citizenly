export { default } from './MigrantInformation';
