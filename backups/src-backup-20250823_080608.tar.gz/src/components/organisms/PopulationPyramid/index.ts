export { default as PopulationPyramid } from './PopulationPyramid';
